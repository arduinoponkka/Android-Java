package my.elsila.jarmoneka;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button USD2EUR, EUR2USD;
    private TextView tulos;
    private EditText syotaValuutta;
    LinearLayout layout;
    public boolean buttonPressed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        USD2EUR = (Button) findViewById(R.id.USD2EUR);
        EUR2USD = (Button) findViewById(R.id.EUR2USD);
        tulos = (TextView) findViewById(R.id.textView);
        syotaValuutta = (EditText) findViewById(R.id.editTextTextPersonName);
        layout = findViewById(R.id.linearlayout);

        USD2EUR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                float number = Float.valueOf(syotaValuutta.getText().toString()) * 0.96f;
                String laskennanTulos = Float.toString(number);
                laskennanTulos += " EUR";
                   tulos.setText(laskennanTulos);

                System.out.println("Painoit USD2EUR.");

            }
        });

        EUR2USD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                float number = Float.valueOf(syotaValuutta.getText().toString()) / 0.96f;
                String laskennanTulos = Float.toString(number);
                laskennanTulos += " USD";
                tulos.setText(laskennanTulos);

                System.out.println("Painoit EUR2USD.");

            }
        });


    }
}